﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace COS.Security
{
    public class SecurityHelper
    {
        public static string SecurityKey { get { return "GHTver7895GDTE789956dee4e8e8efe45efg84erg5er4"; } }
    }
}
