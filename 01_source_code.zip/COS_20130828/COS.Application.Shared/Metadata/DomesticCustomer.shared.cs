﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace COS.Application.Shared
{
    public partial class DomesticCustomer
    {

        public override string ToString()
        {
            return this.CustomerName;
        }
    }
}
