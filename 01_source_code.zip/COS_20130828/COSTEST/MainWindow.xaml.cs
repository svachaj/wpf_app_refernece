﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Diagnostics;

namespace COSTEST
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            dotMath.EqCompiler comp = new dotMath.EqCompiler(true);

            comp.SetVariable("difficulty", 30);

            comp.SetFunction("case(difficulty<10;1;difficulty<20;2;difficulty<30;3;difficulty<40;4;difficulty<50;5;difficulty<60;6;difficulty<70;7;difficulty<80;8;difficulty<90;9;difficulty<100;10;0)");

            var res = comp.Calculate();
        }

        void webBrowser1_Navigated(object sender, NavigationEventArgs e)
        {

        }
    }
}
