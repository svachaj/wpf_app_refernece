namespace COS.Application.Reporting.Reports
{
    partial class DomLogisticForwarder
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DomLogisticForwarder));
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup12 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.tbGridDate = new Telerik.Reporting.TextBox();
            this.tbGridPointOfOrigin = new Telerik.Reporting.TextBox();
            this.tbGridCustomer = new Telerik.Reporting.TextBox();
            this.tbGridDestination = new Telerik.Reporting.TextBox();
            this.tbGridAddress = new Telerik.Reporting.TextBox();
            this.tbGridRound = new Telerik.Reporting.TextBox();
            this.tbGridDriver = new Telerik.Reporting.TextBox();
            this.tbGridCarType = new Telerik.Reporting.TextBox();
            this.tbGridVolume = new Telerik.Reporting.TextBox();
            this.tbGridPrice = new Telerik.Reporting.TextBox();
            this.tbGridDistance = new Telerik.Reporting.TextBox();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.tbForwarder = new Telerik.Reporting.TextBox();
            this.pictureBox1 = new Telerik.Reporting.PictureBox();
            this.pb1 = new Telerik.Reporting.PictureBox();
            this.tbForwarderName = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.tblMain = new Telerik.Reporting.Table();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.textBox6 = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.textBox9 = new Telerik.Reporting.TextBox();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.textBox10 = new Telerik.Reporting.TextBox();
            this.textBox12 = new Telerik.Reporting.TextBox();
            this.textBox14 = new Telerik.Reporting.TextBox();
            this.textBox16 = new Telerik.Reporting.TextBox();
            this.pageFooterSection1 = new Telerik.Reporting.PageFooterSection();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // tbGridDate
            // 
            this.tbGridDate.Name = "tbGridDate";
            this.tbGridDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0172710418701172D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridDate.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridDate.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridDate.Style.Color = System.Drawing.Color.White;
            this.tbGridDate.Style.Font.Bold = true;
            this.tbGridDate.Style.Font.Name = "Arial Narrow";
            this.tbGridDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridDate.Value = "Datum";
            // 
            // tbGridPointOfOrigin
            // 
            this.tbGridPointOfOrigin.Name = "tbGridPointOfOrigin";
            this.tbGridPointOfOrigin.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2115015983581543D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridPointOfOrigin.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridPointOfOrigin.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridPointOfOrigin.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridPointOfOrigin.Style.Color = System.Drawing.Color.White;
            this.tbGridPointOfOrigin.Style.Font.Bold = true;
            this.tbGridPointOfOrigin.Style.Font.Name = "Arial Narrow";
            this.tbGridPointOfOrigin.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridPointOfOrigin.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridPointOfOrigin.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridPointOfOrigin.Value = "Expedov�no";
            // 
            // tbGridCustomer
            // 
            this.tbGridCustomer.Name = "tbGridCustomer";
            this.tbGridCustomer.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.2320108413696289D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridCustomer.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridCustomer.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridCustomer.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridCustomer.Style.Color = System.Drawing.Color.White;
            this.tbGridCustomer.Style.Font.Bold = true;
            this.tbGridCustomer.Style.Font.Name = "Arial Narrow";
            this.tbGridCustomer.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridCustomer.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridCustomer.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridCustomer.Value = "Z�kazn�ci";
            // 
            // tbGridDestination
            // 
            this.tbGridDestination.Name = "tbGridDestination";
            this.tbGridDestination.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.9966521263122559D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridDestination.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridDestination.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridDestination.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridDestination.Style.Color = System.Drawing.Color.White;
            this.tbGridDestination.Style.Font.Bold = true;
            this.tbGridDestination.Style.Font.Name = "Arial Narrow";
            this.tbGridDestination.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridDestination.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridDestination.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridDestination.StyleName = "";
            this.tbGridDestination.Value = "C�lov� destinace";
            // 
            // tbGridAddress
            // 
            this.tbGridAddress.Name = "tbGridAddress";
            this.tbGridAddress.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.0998353958129883D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridAddress.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridAddress.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridAddress.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridAddress.Style.Color = System.Drawing.Color.White;
            this.tbGridAddress.Style.Font.Bold = true;
            this.tbGridAddress.Style.Font.Name = "Arial Narrow";
            this.tbGridAddress.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridAddress.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridAddress.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridAddress.StyleName = "";
            this.tbGridAddress.Value = "Adresa";
            // 
            // tbGridRound
            // 
            this.tbGridRound.Name = "tbGridRound";
            this.tbGridRound.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.895561158657074D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridRound.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridRound.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridRound.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridRound.Style.Color = System.Drawing.Color.White;
            this.tbGridRound.Style.Font.Bold = true;
            this.tbGridRound.Style.Font.Name = "Arial Narrow";
            this.tbGridRound.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridRound.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridRound.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridRound.StyleName = "";
            this.tbGridRound.Value = "Kolo";
            // 
            // tbGridDriver
            // 
            this.tbGridDriver.Name = "tbGridDriver";
            this.tbGridDriver.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2601830959320068D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridDriver.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridDriver.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridDriver.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridDriver.Style.Color = System.Drawing.Color.White;
            this.tbGridDriver.Style.Font.Bold = true;
            this.tbGridDriver.Style.Font.Name = "Arial Narrow";
            this.tbGridDriver.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridDriver.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridDriver.StyleName = "";
            this.tbGridDriver.Value = "�idi�";
            // 
            // tbGridCarType
            // 
            this.tbGridCarType.Name = "tbGridCarType";
            this.tbGridCarType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7099751234054565D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridCarType.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridCarType.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridCarType.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridCarType.Style.Color = System.Drawing.Color.White;
            this.tbGridCarType.Style.Font.Bold = true;
            this.tbGridCarType.Style.Font.Name = "Arial Narrow";
            this.tbGridCarType.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridCarType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridCarType.StyleName = "";
            this.tbGridCarType.Value = "Typ auta";
            // 
            // tbGridVolume
            // 
            this.tbGridVolume.Name = "tbGridVolume";
            this.tbGridVolume.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2337249517440796D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridVolume.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridVolume.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridVolume.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridVolume.Style.Color = System.Drawing.Color.White;
            this.tbGridVolume.Style.Font.Bold = true;
            this.tbGridVolume.Style.Font.Name = "Arial Narrow";
            this.tbGridVolume.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridVolume.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridVolume.StyleName = "";
            this.tbGridVolume.Value = "Objem";
            // 
            // tbGridPrice
            // 
            this.tbGridPrice.Name = "tbGridPrice";
            this.tbGridPrice.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.92164146900177D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridPrice.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridPrice.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridPrice.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridPrice.Style.Color = System.Drawing.Color.White;
            this.tbGridPrice.Style.Font.Bold = true;
            this.tbGridPrice.Style.Font.Name = "Arial Narrow";
            this.tbGridPrice.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridPrice.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridPrice.StyleName = "";
            this.tbGridPrice.Value = "Cena";
            // 
            // tbGridDistance
            // 
            this.tbGridDistance.Name = "tbGridDistance";
            this.tbGridDistance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.92164146900177D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridDistance.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridDistance.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridDistance.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridDistance.Style.Color = System.Drawing.Color.White;
            this.tbGridDistance.Style.Font.Bold = true;
            this.tbGridDistance.Style.Font.Name = "Arial Narrow";
            this.tbGridDistance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridDistance.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridDistance.StyleName = "";
            this.tbGridDistance.Value = "Vzd�lenost";
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.5D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.tbForwarder,
            this.pictureBox1,
            this.pb1,
            this.tbForwarderName});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            // 
            // tbForwarder
            // 
            this.tbForwarder.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.3000001907348633D), Telerik.Reporting.Drawing.Unit.Cm(0.30000004172325134D));
            this.tbForwarder.Name = "tbForwarder";
            this.tbForwarder.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.7000012397766113D), Telerik.Reporting.Drawing.Unit.Cm(0.99999988079071045D));
            this.tbForwarder.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.tbForwarder.Style.Font.Bold = true;
            this.tbForwarder.Style.Font.Italic = false;
            this.tbForwarder.Style.Font.Name = "Segoe UI";
            this.tbForwarder.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(20D);
            this.tbForwarder.Style.Font.Underline = false;
            this.tbForwarder.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.tbForwarder.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbForwarder.Value = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.011463165283203D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.pictureBox1.MimeType = "image/jpeg";
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5885367393493652D), Telerik.Reporting.Drawing.Unit.Cm(1.2999999523162842D));
            this.pictureBox1.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pictureBox1.Value = ((object)(resources.GetObject("pictureBox1.Value")));
            // 
            // pb1
            // 
            this.pb1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.pb1.MimeType = "image/jpeg";
            this.pb1.Name = "pb1";
            this.pb1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(1.2999999523162842D));
            this.pb1.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pb1.Value = ((object)(resources.GetObject("pb1.Value")));
            // 
            // tbForwarderName
            // 
            this.tbForwarderName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.300000190734863D), Telerik.Reporting.Drawing.Unit.Cm(0.30000004172325134D));
            this.tbForwarderName.Name = "tbForwarderName";
            this.tbForwarderName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.3999996185302734D), Telerik.Reporting.Drawing.Unit.Cm(0.99999988079071045D));
            this.tbForwarderName.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.tbForwarderName.Style.Font.Bold = true;
            this.tbForwarderName.Style.Font.Italic = false;
            this.tbForwarderName.Style.Font.Name = "Segoe UI";
            this.tbForwarderName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(20D);
            this.tbForwarderName.Style.Font.Underline = false;
            this.tbForwarderName.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.tbForwarderName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbForwarderName.Value = "";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(7.1999998092651367D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.tblMain});
            this.detail.Name = "detail";
            // 
            // tblMain
            // 
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.0172712802886963D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.2115013599395752D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(4.2320108413696289D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(4.9966521263122559D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5.0998353958129883D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.89556097984313965D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.2601830959320068D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.7099751234054565D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.2337249517440796D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.92164146900177D)));
            this.tblMain.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.92164146900177D)));
            this.tblMain.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D)));
            this.tblMain.Body.SetCellContent(0, 0, this.textBox4);
            this.tblMain.Body.SetCellContent(0, 1, this.textBox5);
            this.tblMain.Body.SetCellContent(0, 2, this.textBox6);
            this.tblMain.Body.SetCellContent(0, 3, this.textBox2);
            this.tblMain.Body.SetCellContent(0, 4, this.textBox7);
            this.tblMain.Body.SetCellContent(0, 5, this.textBox9);
            this.tblMain.Body.SetCellContent(0, 6, this.textBox3);
            this.tblMain.Body.SetCellContent(0, 7, this.textBox10);
            this.tblMain.Body.SetCellContent(0, 8, this.textBox12);
            this.tblMain.Body.SetCellContent(0, 9, this.textBox14);
            this.tblMain.Body.SetCellContent(0, 10, this.textBox16);
            tableGroup1.ReportItem = this.tbGridDate;
            tableGroup2.ReportItem = this.tbGridPointOfOrigin;
            tableGroup3.ReportItem = this.tbGridCustomer;
            tableGroup4.Name = "Group1";
            tableGroup4.ReportItem = this.tbGridDestination;
            tableGroup5.Name = "Group2";
            tableGroup5.ReportItem = this.tbGridAddress;
            tableGroup6.Name = "Group3";
            tableGroup6.ReportItem = this.tbGridRound;
            tableGroup7.Name = "Group4";
            tableGroup7.ReportItem = this.tbGridDriver;
            tableGroup8.Name = "Group5";
            tableGroup8.ReportItem = this.tbGridCarType;
            tableGroup9.Name = "Group6";
            tableGroup9.ReportItem = this.tbGridVolume;
            tableGroup10.Name = "Group7";
            tableGroup10.ReportItem = this.tbGridPrice;
            tableGroup11.Name = "Group8";
            tableGroup11.ReportItem = this.tbGridDistance;
            this.tblMain.ColumnGroups.Add(tableGroup1);
            this.tblMain.ColumnGroups.Add(tableGroup2);
            this.tblMain.ColumnGroups.Add(tableGroup3);
            this.tblMain.ColumnGroups.Add(tableGroup4);
            this.tblMain.ColumnGroups.Add(tableGroup5);
            this.tblMain.ColumnGroups.Add(tableGroup6);
            this.tblMain.ColumnGroups.Add(tableGroup7);
            this.tblMain.ColumnGroups.Add(tableGroup8);
            this.tblMain.ColumnGroups.Add(tableGroup9);
            this.tblMain.ColumnGroups.Add(tableGroup10);
            this.tblMain.ColumnGroups.Add(tableGroup11);
            this.tblMain.ColumnHeadersPrintOnEveryPage = true;
            this.tblMain.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox4,
            this.textBox5,
            this.textBox6,
            this.textBox2,
            this.textBox7,
            this.textBox9,
            this.textBox3,
            this.textBox10,
            this.textBox12,
            this.textBox14,
            this.textBox16,
            this.tbGridDate,
            this.tbGridPointOfOrigin,
            this.tbGridCustomer,
            this.tbGridDestination,
            this.tbGridAddress,
            this.tbGridRound,
            this.tbGridDriver,
            this.tbGridCarType,
            this.tbGridVolume,
            this.tbGridPrice,
            this.tbGridDistance});
            this.tblMain.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D), Telerik.Reporting.Drawing.Unit.Cm(0.19999989867210388D));
            this.tblMain.Name = "tblMain";
            tableGroup12.Groupings.AddRange(new Telerik.Reporting.Grouping[] {
            new Telerik.Reporting.Grouping(null)});
            tableGroup12.Name = "DetailGroup";
            this.tblMain.RowGroups.Add(tableGroup12);
            this.tblMain.RowHeadersPrintOnEveryPage = true;
            this.tblMain.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.499996185302734D), Telerik.Reporting.Drawing.Unit.Cm(1.2170838117599487D));
            // 
            // textBox4
            // 
            this.textBox4.Format = "{0:d}";
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0172710418701172D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox4.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox4.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.textBox4.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox4.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox4.Value = "=Fields.PlannedDate";
            // 
            // textBox5
            // 
            this.textBox5.Format = "{0:N2}";
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2115015983581543D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox5.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox5.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox5.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox5.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox5.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox5.Value = "=Fields.PointOfOrigin.DestinationName";
            // 
            // textBox6
            // 
            this.textBox6.Format = "{0:N2}";
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.2320108413696289D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox6.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox6.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox6.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox6.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox6.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox6.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox6.Value = "=Fields.DetailsCustomersString";
            // 
            // textBox2
            // 
            this.textBox2.Format = "{0:N2}";
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.9966521263122559D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox2.StyleName = "";
            this.textBox2.Value = "=Fields.DetailsDestinationsString";
            // 
            // textBox7
            // 
            this.textBox7.Format = "{0:N2}";
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.0998353958129883D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox7.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox7.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox7.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox7.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox7.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox7.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox7.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox7.StyleName = "";
            this.textBox7.Value = "=Fields.AddressString";
            // 
            // textBox9
            // 
            this.textBox9.Format = "{0:N0}";
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.895561158657074D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox9.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox9.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox9.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox9.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox9.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox9.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox9.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox9.StyleName = "";
            this.textBox9.Value = "=Fields.Round";
            // 
            // textBox3
            // 
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2601830959320068D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox3.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox3.StyleName = "";
            this.textBox3.Value = "=Fields.Driver.Name";
            // 
            // textBox10
            // 
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7099751234054565D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox10.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox10.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox10.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox10.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox10.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox10.StyleName = "";
            this.textBox10.Value = "=Fields.CarType.CarTypeName";
            // 
            // textBox12
            // 
            this.textBox12.Format = "{0:N0}";
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2337249517440796D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox12.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox12.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.textBox12.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox12.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox12.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox12.StyleName = "";
            this.textBox12.Value = "=Fields.TotalVolume";
            // 
            // textBox14
            // 
            this.textBox14.Format = "{0:C0}";
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.92164146900177D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox14.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox14.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox14.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.textBox14.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox14.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox14.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox14.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox14.StyleName = "";
            this.textBox14.Value = "=Fields.TotalPrice";
            // 
            // textBox16
            // 
            this.textBox16.Format = "{0:N0}";
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.92164146900177D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox16.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox16.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox16.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.textBox16.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox16.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.textBox16.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox16.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox16.StyleName = "";
            this.textBox16.Value = "=Fields.TotalDistance";
            // 
            // pageFooterSection1
            // 
            this.pageFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.39999979734420776D);
            this.pageFooterSection1.Name = "pageFooterSection1";
            // 
            // DomLogisticForwarder
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail,
            this.pageFooterSection1});
            this.Name = "DomLogisticForwarder";
            this.PageSettings.Landscape = true;
            this.PageSettings.Margins.Bottom = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.Margins.Left = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.Margins.Right = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.Margins.Top = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            this.Style.BackgroundColor = System.Drawing.Color.White;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.700000762939453D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.PageFooterSection pageFooterSection1;
        private Telerik.Reporting.TextBox tbForwarder;
        private Telerik.Reporting.PictureBox pictureBox1;
        private Telerik.Reporting.PictureBox pb1;
        private Telerik.Reporting.TextBox tbForwarderName;
        private Telerik.Reporting.Table tblMain;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.TextBox textBox5;
        private Telerik.Reporting.TextBox textBox6;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox textBox9;
        private Telerik.Reporting.TextBox textBox3;
        private Telerik.Reporting.TextBox textBox10;
        private Telerik.Reporting.TextBox textBox12;
        private Telerik.Reporting.TextBox textBox14;
        private Telerik.Reporting.TextBox textBox16;
        private Telerik.Reporting.TextBox tbGridDate;
        private Telerik.Reporting.TextBox tbGridPointOfOrigin;
        private Telerik.Reporting.TextBox tbGridCustomer;
        private Telerik.Reporting.TextBox tbGridDestination;
        private Telerik.Reporting.TextBox tbGridAddress;
        private Telerik.Reporting.TextBox tbGridRound;
        private Telerik.Reporting.TextBox tbGridDriver;
        private Telerik.Reporting.TextBox tbGridCarType;
        private Telerik.Reporting.TextBox tbGridVolume;
        private Telerik.Reporting.TextBox tbGridPrice;
        private Telerik.Reporting.TextBox tbGridDistance;
    }
}