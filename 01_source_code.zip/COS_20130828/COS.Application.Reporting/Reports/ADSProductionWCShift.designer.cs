namespace COS.Application.Reporting.Reports
{
    partial class ADSProductionWCShift
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADSProductionWCShift));
            this.tbGridWc = new Telerik.Reporting.TextBox();
            this.tbGridPerformance = new Telerik.Reporting.TextBox();
            this.tbGridAvailability = new Telerik.Reporting.TextBox();
            this.tbGridQuality = new Telerik.Reporting.TextBox();
            this.tbGridOee = new Telerik.Reporting.TextBox();
            this.tbGridActualtime = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.table1 = new Telerik.Reporting.Table();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.textBox6 = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.textBox9 = new Telerik.Reporting.TextBox();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.pb1 = new Telerik.Reporting.PictureBox();
            this.pictureBox1 = new Telerik.Reporting.PictureBox();
            this.tbHeader = new Telerik.Reporting.TextBox();
            this.tbShift = new Telerik.Reporting.TextBox();
            this.shape2 = new Telerik.Reporting.Shape();
            this.tbDivision = new Telerik.Reporting.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // tbGridWc
            // 
            this.tbGridWc.Name = "tbGridWc";
            this.tbGridWc.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.321378231048584D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridWc.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridWc.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridWc.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridWc.Style.Color = System.Drawing.Color.White;
            this.tbGridWc.Style.Font.Bold = true;
            this.tbGridWc.Style.Font.Name = "Arial Narrow";
            this.tbGridWc.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridWc.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridWc.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridWc.Value = "Wc";
            // 
            // tbGridPerformance
            // 
            this.tbGridPerformance.Name = "tbGridPerformance";
            this.tbGridPerformance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6902377605438232D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridPerformance.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridPerformance.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridPerformance.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridPerformance.Style.Color = System.Drawing.Color.White;
            this.tbGridPerformance.Style.Font.Bold = true;
            this.tbGridPerformance.Style.Font.Name = "Arial Narrow";
            this.tbGridPerformance.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridPerformance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridPerformance.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridPerformance.Value = "V�kon";
            // 
            // tbGridAvailability
            // 
            this.tbGridAvailability.Name = "tbGridAvailability";
            this.tbGridAvailability.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1460855007171631D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridAvailability.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridAvailability.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridAvailability.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridAvailability.Style.Color = System.Drawing.Color.White;
            this.tbGridAvailability.Style.Font.Bold = true;
            this.tbGridAvailability.Style.Font.Name = "Arial Narrow";
            this.tbGridAvailability.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridAvailability.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridAvailability.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridAvailability.Value = "Dostupnost";
            // 
            // tbGridQuality
            // 
            this.tbGridQuality.Name = "tbGridQuality";
            this.tbGridQuality.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0318722724914551D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridQuality.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridQuality.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridQuality.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridQuality.Style.Color = System.Drawing.Color.White;
            this.tbGridQuality.Style.Font.Bold = true;
            this.tbGridQuality.Style.Font.Name = "Arial Narrow";
            this.tbGridQuality.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridQuality.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridQuality.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridQuality.StyleName = "";
            this.tbGridQuality.Value = "Kvalita";
            // 
            // tbGridOee
            // 
            this.tbGridOee.Name = "tbGridOee";
            this.tbGridOee.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0847883224487305D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridOee.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridOee.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridOee.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridOee.Style.Color = System.Drawing.Color.White;
            this.tbGridOee.Style.Font.Bold = true;
            this.tbGridOee.Style.Font.Name = "Arial Narrow";
            this.tbGridOee.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridOee.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridOee.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridOee.StyleName = "";
            this.tbGridOee.Value = "OEE";
            // 
            // tbGridActualtime
            // 
            this.tbGridActualtime.Name = "tbGridActualtime";
            this.tbGridActualtime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5610413551330566D), Telerik.Reporting.Drawing.Unit.Cm(0.63500016927719116D));
            this.tbGridActualtime.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tbGridActualtime.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tbGridActualtime.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.tbGridActualtime.Style.Color = System.Drawing.Color.White;
            this.tbGridActualtime.Style.Font.Bold = true;
            this.tbGridActualtime.Style.Font.Name = "Arial Narrow";
            this.tbGridActualtime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.tbGridActualtime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbGridActualtime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbGridActualtime.StyleName = "";
            this.tbGridActualtime.Value = "Dostupn� �as";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.7999999523162842D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.table1});
            this.detail.Name = "detail";
            // 
            // table1
            // 
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.3213684558868408D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.6902334690093994D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.1460778713226318D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.0318717956542969D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.0847883224487305D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.5610418319702148D)));
            this.table1.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D)));
            this.table1.Body.SetCellContent(0, 0, this.textBox4);
            this.table1.Body.SetCellContent(0, 1, this.textBox5);
            this.table1.Body.SetCellContent(0, 2, this.textBox6);
            this.table1.Body.SetCellContent(0, 3, this.textBox2);
            this.table1.Body.SetCellContent(0, 4, this.textBox7);
            this.table1.Body.SetCellContent(0, 5, this.textBox9);
            tableGroup1.ReportItem = this.tbGridWc;
            tableGroup2.ReportItem = this.tbGridPerformance;
            tableGroup3.ReportItem = this.tbGridAvailability;
            tableGroup4.Name = "Group1";
            tableGroup4.ReportItem = this.tbGridQuality;
            tableGroup5.Name = "Group2";
            tableGroup5.ReportItem = this.tbGridOee;
            tableGroup6.Name = "Group3";
            tableGroup6.ReportItem = this.tbGridActualtime;
            this.table1.ColumnGroups.Add(tableGroup1);
            this.table1.ColumnGroups.Add(tableGroup2);
            this.table1.ColumnGroups.Add(tableGroup3);
            this.table1.ColumnGroups.Add(tableGroup4);
            this.table1.ColumnGroups.Add(tableGroup5);
            this.table1.ColumnGroups.Add(tableGroup6);
            this.table1.ColumnHeadersPrintOnEveryPage = true;
            this.table1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox4,
            this.textBox5,
            this.textBox6,
            this.textBox2,
            this.textBox7,
            this.textBox9,
            this.tbGridWc,
            this.tbGridPerformance,
            this.tbGridAvailability,
            this.tbGridQuality,
            this.tbGridOee,
            this.tbGridActualtime});
            this.table1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D), Telerik.Reporting.Drawing.Unit.Cm(0.299999862909317D));
            this.table1.Name = "table1";
            tableGroup7.Groupings.AddRange(new Telerik.Reporting.Grouping[] {
            new Telerik.Reporting.Grouping(null)});
            tableGroup7.Name = "DetailGroup";
            this.table1.RowGroups.Add(tableGroup7);
            this.table1.RowHeadersPrintOnEveryPage = true;
            this.table1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.835382461547852D), Telerik.Reporting.Drawing.Unit.Cm(1.2170838117599487D));
            // 
            // textBox4
            // 
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.321378231048584D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox4.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox4.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox4.Value = "=Fields.WorkCenterString";
            // 
            // textBox5
            // 
            this.textBox5.Format = "{0:N2}";
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6902377605438232D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox5.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox5.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox5.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox5.Value = "=Fields.KPIData.KpiPerformance";
            this.textBox5.ItemDataBound += new System.EventHandler(this.textBox5_ItemDataBound);
            // 
            // textBox6
            // 
            this.textBox6.Format = "{0:N2}";
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1460855007171631D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox6.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox6.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox6.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox6.Value = "=Fields.KPIData.KpiAvailability";
            this.textBox6.ItemDataBound += new System.EventHandler(this.textBox6_ItemDataBound);
            // 
            // textBox2
            // 
            this.textBox2.Format = "{0:N2}";
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0318722724914551D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox2.StyleName = "";
            this.textBox2.Value = "=Fields.KPIData.KpiQuality";
            this.textBox2.ItemDataBound += new System.EventHandler(this.textBox2_ItemDataBound);
            // 
            // textBox7
            // 
            this.textBox7.Format = "{0:N2}";
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0847883224487305D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox7.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox7.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox7.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox7.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox7.StyleName = "";
            this.textBox7.Value = "=Fields.KPIData.KpiOEE";
            this.textBox7.ItemDataBound += new System.EventHandler(this.textBox7_ItemDataBound);
            // 
            // textBox9
            // 
            this.textBox9.Format = "{0:N0}";
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5610413551330566D), Telerik.Reporting.Drawing.Unit.Cm(0.58208364248275757D));
            this.textBox9.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox9.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox9.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox9.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox9.StyleName = "";
            this.textBox9.Value = "=Fields.Time";
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(3.8000001907348633D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pb1,
            this.pictureBox1,
            this.tbHeader,
            this.tbShift,
            this.shape2,
            this.tbDivision});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            // 
            // pb1
            // 
            this.pb1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D), Telerik.Reporting.Drawing.Unit.Cm(0.099999964237213135D));
            this.pb1.MimeType = "image/jpeg";
            this.pb1.Name = "pb1";
            this.pb1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(1.2999999523162842D));
            this.pb1.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pb1.Value = ((object)(resources.GetObject("pb1.Value")));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.300000190734863D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.pictureBox1.MimeType = "image/jpeg";
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5885367393493652D), Telerik.Reporting.Drawing.Unit.Cm(1.2999999523162842D));
            this.pictureBox1.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pictureBox1.Value = ((object)(resources.GetObject("pictureBox1.Value")));
            // 
            // tbHeader
            // 
            this.tbHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.11146283149719238D), Telerik.Reporting.Drawing.Unit.Cm(1.3997998237609863D));
            this.tbHeader.Name = "tbHeader";
            this.tbHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.777072906494141D), Telerik.Reporting.Drawing.Unit.Cm(0.99999988079071045D));
            this.tbHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.tbHeader.Style.Font.Bold = true;
            this.tbHeader.Style.Font.Name = "Segoe UI";
            this.tbHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(22D);
            this.tbHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbHeader.Value = "";
            // 
            // tbShift
            // 
            this.tbShift.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D), Telerik.Reporting.Drawing.Unit.Cm(2.4000000953674316D));
            this.tbShift.Name = "tbShift";
            this.tbShift.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.799999237060547D), Telerik.Reporting.Drawing.Unit.Cm(0.99999988079071045D));
            this.tbShift.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.tbShift.Style.Font.Italic = true;
            this.tbShift.Style.Font.Name = "Segoe UI";
            this.tbShift.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(16D);
            this.tbShift.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbShift.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbShift.Value = "";
            // 
            // shape2
            // 
            this.shape2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.11146283149719238D), Telerik.Reporting.Drawing.Unit.Cm(3.4002001285552979D));
            this.shape2.Name = "shape2";
            this.shape2.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.788536071777344D), Telerik.Reporting.Drawing.Unit.Cm(0.2999001145362854D));
            // 
            // tbDivision
            // 
            this.tbDivision.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.5D), Telerik.Reporting.Drawing.Unit.Cm(0.20000000298023224D));
            this.tbDivision.Name = "tbDivision";
            this.tbDivision.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8.3000001907348633D), Telerik.Reporting.Drawing.Unit.Cm(0.99999988079071045D));
            this.tbDivision.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.tbDivision.Style.Font.Italic = false;
            this.tbDivision.Style.Font.Name = "Segoe UI";
            this.tbDivision.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(12D);
            this.tbDivision.Style.Font.Underline = true;
            this.tbDivision.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tbDivision.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.tbDivision.Value = "";
            // 
            // ADSProductionWCShift
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.detail,
            this.pageHeaderSection1});
            this.Name = "Report1";
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins.Bottom = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.Margins.Left = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.Margins.Right = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.Margins.Top = Telerik.Reporting.Drawing.Unit.Mm(10D);
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            this.Style.BackgroundColor = System.Drawing.Color.White;
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18.999898910522461D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.Table table1;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.TextBox textBox5;
        private Telerik.Reporting.TextBox textBox6;
        private Telerik.Reporting.TextBox tbGridWc;
        private Telerik.Reporting.TextBox tbGridPerformance;
        private Telerik.Reporting.TextBox tbGridAvailability;
        private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
        private Telerik.Reporting.TextBox tbHeader;
        private Telerik.Reporting.TextBox tbShift;
        private Telerik.Reporting.PictureBox pb1;
        private Telerik.Reporting.PictureBox pictureBox1;
        private Telerik.Reporting.Shape shape2;
        private Telerik.Reporting.TextBox tbDivision;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox textBox9;
        private Telerik.Reporting.TextBox tbGridQuality;
        private Telerik.Reporting.TextBox tbGridOee;
        private Telerik.Reporting.TextBox tbGridActualtime;
    }
}