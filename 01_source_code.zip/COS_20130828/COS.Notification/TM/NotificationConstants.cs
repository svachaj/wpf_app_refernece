﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace COS.Notification.TM
{
    public class NotificationConstants
    {
        public const string LimitToolNotification = "LimitToolNotification";
        public const string OverflowToolNotification = "OverflowToolNotification";
    }
}
